# SearchSelectedTextChrome

Add keyboard shortcut to search highlighted selected text on google in a new tab. 
For dev, go to chrome://extensions/ to add the plugin.
